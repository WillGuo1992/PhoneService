/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cn.edu.buaa.nlsde.wlan.datapre;

import cn.edu.buaa.nlsde.wlan.beans.WifiMessage;

/**
 * 接收数据处理类
 *
 * @author lawson
 */
public class ReceiveDataProcesser {

	public void dataStoreProcess(WifiMessage msg) {
	}

	public void dataPrepare() {
	}
}
