package nlsde.junction.topbar;

public interface TopBarClickListener {
		void leftBtnClick();  
 		void rightBtnClick(); 
}
