/**
 * ViewHolder.java
 * 
 * @Description: 
 * 
 * @File: ViewHolder.java
 * 
 * @Package nlsde.baidu
 * 
 * @Author chaos
 * 
 * @Date 2014-12-3上午11:04:20
 * 
 * @Version V1.0
 */
package nlsde.baidu;

import android.widget.ImageView;
import android.widget.TextView;

/**
 * @author Administrator
 *
 */
public class ViewHolder {
 
	    ImageView infoImg;  
	    TextView infoName;  
	    TextView infoDistance;  
	    TextView infoZan;  
	 
}
