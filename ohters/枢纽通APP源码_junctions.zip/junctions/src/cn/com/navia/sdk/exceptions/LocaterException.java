package cn.com.navia.sdk.exceptions;

public class LocaterException extends Exception {

	private static final long serialVersionUID = 1L;

	public LocaterException() {
		super();
	}

	

	public LocaterException(String arg0, Throwable arg1) {
		super(arg0, arg1);
	}

	public LocaterException(String arg0) {
		super(arg0);
	}

	public LocaterException(Throwable arg0) {
		super(arg0);
	}

}
