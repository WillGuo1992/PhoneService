/* 
 * Spectrum.java
 *
 * create on 2013-10-28,14:20:48
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */
package cn.edu.buaa.nlsde.wlan.resource;

/**
 * 读取频谱文件及存储相关信息
 *
 * @author Lei
 */
public class Spectrum {

}
