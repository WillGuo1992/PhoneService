/**
 * Bike_ViewHolder.java
 * 
 * @Description: 
 * 
 * @File: Bike_ViewHolder.java
 * 
 * @Package nlsde.junction.home.function
 * 
 * @Author chaos
 * 
 * @Date 2014-12-4下午1:57:00
 * 
 * @Version V1.0
 */
package nlsde.junction.home.function;

import android.widget.Button;
import android.widget.TextView;

/**
 * @author Administrator
 *
 */
public class Bike_ViewHolder {

	TextView bike_Net_LocationtTextView;
	TextView bike_totalTextView;
	TextView bike_residualTextView;
	TextView bike_net_infoTextView;
	Button bike_refreshButton;
	Button bike_cancelButton;
}
