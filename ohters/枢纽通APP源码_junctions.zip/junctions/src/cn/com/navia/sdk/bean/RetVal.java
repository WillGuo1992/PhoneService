package cn.com.navia.sdk.bean;

/**
 * Created by gaojie on 15-2-27.
 */
public abstract class RetVal {

    private int c;
    private String m;

    public int getC() {
        return c;
    }

    public abstract Object getD() ;

    public String getM() {
        return m;
    }
}
