package cn.com.navia.sdk.bean;

/**
 *
 * RetVal_LatestVersion
 * Created by gaojie on 15-2-27.
 */
public class RetVal_LatestVersion extends  RetVal {

    private RetVal_UpdateItem d;

    public RetVal_UpdateItem getD(){
        return d;
    }
}
