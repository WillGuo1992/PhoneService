package cn.com.navia.sdk.bean;

import java.util.List;

/**
 * Created by gaojie on 15-2-27.
 */
public class RetVal_LatestList extends RetVal {

    private List<RetVal_UpdateItem> d;

    public List<RetVal_UpdateItem> getD(){
        return d;
    };

}
