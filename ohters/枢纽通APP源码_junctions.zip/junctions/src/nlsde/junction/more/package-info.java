/**
 * 
 */
/**
 * @author bingoc
 *
 */
package nlsde.junction.more;